/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import dto.Player;
import java.sql.*;
/**
 *
 * @author ANJANA SAHU
 */
public class PlayerDAO {
    
    private Connection con;

    public PlayerDAO(Connection con) {
        this.con = con;
    }

   public boolean savePlayer(Player p)
   {
      boolean f = false;
      
      String query = "insert into player(name,username,password,email,DOB,experience,role) values(?,?,?,?,?,?,?)";
       try {
           
           PreparedStatement ps =  this.con.prepareStatement(query);
           ps.setString(1, p.getName());
           ps.setString(2, p.getUsername());
           ps.setString(3, p.getPassword());
           ps.setString(4, p.getEmail());
           ps.setString(5, p.getDOB());
           ps.setString(6, p.getExperience());
           ps.setString(7, p.getRole());
          
           ps.executeUpdate();
                 f = true;
       } catch (Exception e) {
           e.printStackTrace();
       }
      
      return f;
   
}
}
